/**
 * Responsável por desenhar a cobra no canvas.
 */
export class SnakeRenderer {
    constructor(ctx, gridSize) {
        this.ctx = ctx;
        this.gridSize = gridSize;
    }

    draw(snakeBody) {
        const { ctx } = this;
        ctx.fillStyle = '#f9c95bff';
        ctx.strokeStyle = 'black';
        ctx.lineWidth = 2;

        snakeBody.forEach((part, index) => {
            const nextPart = snakeBody[index + 1];
            const prevPart = snakeBody[index - 1];

            if (index === 0 && nextPart) {
                this.#drawHead(part, nextPart);
            } else if (index > 0 && index < snakeBody.length - 1) {
                this.#drawBody(part, prevPart, nextPart);
            } else if (index === snakeBody.length - 1 && prevPart) {
                this.#drawTail(part, prevPart);
            }
        });
    }

    static partDirection(current, next) {
        if (!next) return null;
        if (current.x < next.x) return 'left';
        if (current.x > next.x) return 'right';
        if (current.y < next.y) return 'up';
        if (current.y > next.y) return 'down';
        return null;
    }

    static closedSides(dirPrev, dirNext) {
        if (!dirPrev || !dirNext) {
            return new Set(['left', 'right', 'top', 'bottom']);
        }

        const sides = new Set(['left', 'right', 'top', 'bottom']);

        const removalByPrevDirection = { left: 'left', right: 'right', up: 'top', down: 'bottom' };
        const removalByNextDirection = { left: 'right', right: 'left', up: 'bottom', down: 'top' };

        sides.delete(removalByPrevDirection[dirPrev]);
        sides.delete(removalByNextDirection[dirNext]);

        return sides;
    }

    #drawHead(part, nextPart) {
        const { ctx, gridSize } = this;
        const dir = SnakeRenderer.partDirection(part, nextPart);
        const r = gridSize / 2;
        const cx = part.x + r;
        const cy = part.y + r;

        this.#drawHeadShape(part, dir, r, cy);
        ctx.fill();
        ctx.stroke();

        this.#drawEyes(part, dir);
        this.#drawMouth(part, dir);
        this.#drawHeadphones(cx, cy, dir);
    }

    #drawHeadShape(part, dir, r, cy) {
        const { ctx, gridSize } = this;
        ctx.beginPath();
        switch (dir) {
            case 'left':
                ctx.moveTo(part.x + gridSize, part.y);
                ctx.lineTo(part.x + r, part.y);
                ctx.arc(part.x + r, cy, r, -Math.PI / 2, Math.PI / 2, true);
                ctx.lineTo(part.x + gridSize, part.y + gridSize);
                break;
            case 'right':
                ctx.moveTo(part.x, part.y);
                ctx.lineTo(part.x + r, part.y);
                ctx.arc(part.x + r, cy, r, -Math.PI / 2, Math.PI / 2, false);
                ctx.lineTo(part.x, part.y + gridSize);
                break;
            case 'down':
                ctx.moveTo(part.x + gridSize, part.y);
                ctx.arc(part.x + r, part.y + r, r, 0, Math.PI, false);
                ctx.lineTo(part.x, part.y);
                break;
            case 'up':
                ctx.moveTo(part.x + gridSize, part.y + gridSize);
                ctx.arc(part.x + r, part.y + r, r, 0, Math.PI, true);
                ctx.lineTo(part.x, part.y + gridSize);
                break;
            default:
                ctx.rect(part.x, part.y, gridSize, gridSize);
                break;
        }
    }

    #drawEyes(part, dir) {
        const { ctx, gridSize } = this;
        ctx.fillStyle = 'white';
        ctx.strokeStyle = 'black';
        const eyeRadius = gridSize * 0.12;

        const eyePositionsByDirection = {
            left: { eye1x: part.x + gridSize * 0.55, eye2x: part.x + gridSize * 0.55, eye1y: part.y + gridSize * 0.25, eye2y: part.y + gridSize * 0.75 },
            right: { eye1x: part.x + gridSize * 0.45, eye2x: part.x + gridSize * 0.45, eye1y: part.y + gridSize * 0.25, eye2y: part.y + gridSize * 0.75 },
            up: { eye1x: part.x + gridSize * 0.25, eye2x: part.x + gridSize * 0.75, eye1y: part.y + gridSize * 0.55, eye2y: part.y + gridSize * 0.55 },
            down: { eye1x: part.x + gridSize * 0.25, eye2x: part.x + gridSize * 0.75, eye1y: part.y + gridSize * 0.45, eye2y: part.y + gridSize * 0.45 },
        };

        const { eye1x, eye1y, eye2x, eye2y } = eyePositionsByDirection[dir] ?? eyePositionsByDirection.right;

        ctx.beginPath();
        ctx.arc(eye1x, eye1y, eyeRadius, 0, Math.PI * 2);
        ctx.moveTo(eye2x + eyeRadius, eye2y);
        ctx.arc(eye2x, eye2y, eyeRadius, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = 'black';
        const pupilRadius = eyeRadius / 1.5;
        ctx.beginPath();
        ctx.arc(eye1x, eye1y, pupilRadius, 0, Math.PI * 2);
        ctx.arc(eye2x, eye2y, pupilRadius, 0, Math.PI * 2);
        ctx.fill();
    }

    #drawMouth(part, dir) {
        const { ctx, gridSize } = this;
        ctx.strokeStyle = '#722F37';
        ctx.lineWidth = 5;
        ctx.beginPath();

        switch (dir) {
            case 'left':
                ctx.moveTo(part.x + gridSize * -0.3, part.y + gridSize * 0.45);
                ctx.lineTo(part.x, part.y + gridSize * 0.5);
                ctx.lineTo(part.x + gridSize * -0.3, part.y + gridSize * 0.65);
                break;
            case 'right':
                ctx.moveTo(part.x + gridSize * 1.3, part.y + gridSize * 0.45);
                ctx.lineTo(part.x + gridSize, part.y + gridSize * 0.5);
                ctx.lineTo(part.x + gridSize * 1.3, part.y + gridSize * 0.65);
                break;
            case 'up':
                ctx.moveTo(part.x + gridSize * 0.35, part.y + gridSize * -0.4);
                ctx.lineTo(part.x + gridSize * 0.5, part.y);
                ctx.lineTo(part.x + gridSize * 0.65, part.y + gridSize * -0.4);
                break;
            case 'down':
                ctx.moveTo(part.x + gridSize * 0.35, part.y + gridSize * 1.2);
                ctx.lineTo(part.x + gridSize * 0.5, part.y + gridSize);
                ctx.lineTo(part.x + gridSize * 0.65, part.y + gridSize * 1.2);
                break;
        }
        ctx.stroke();
    }

    #drawHeadphones(cx, cy, dir) {
        const { ctx, gridSize } = this;
        ctx.save();
        ctx.strokeStyle = '#5c5959ff';
        ctx.lineWidth = gridSize * 0.1;
        ctx.lineCap = 'round';

        ctx.beginPath();
        switch (dir) {
            case 'left':
                ctx.arc(cx, cy, gridSize * 0.65, Math.PI * -0.5, Math.PI * -1.5);
                ctx.stroke();
                break;
            case 'right':
                ctx.arc(cx, cy, gridSize * 0.65, Math.PI * 0.5, Math.PI * 1.5);
                ctx.stroke();
                break;
            case 'up':
                ctx.arc(cx, cy, gridSize * 0.65, 0, Math.PI);
                ctx.stroke();
                break;
            case 'down':
                ctx.arc(cx, cy, gridSize * 0.65, Math.PI, 0);
                ctx.stroke();
                break;
        }

        if (dir === 'left' || dir === 'right') {
            this.#drawEarCup(cx, cy + gridSize * 0.6, gridSize * 0.2, 0, Math.PI);
            this.#drawEarCup(cx, cy - gridSize * 0.6, gridSize * 0.2, Math.PI, 0);
        } else if (dir === 'up' || dir === 'down') {
            this.#drawEarCup(cx - gridSize * 0.6, cy, gridSize * 0.2, Math.PI * 0.5, Math.PI * 1.5);
            this.#drawEarCup(cx + gridSize * 0.6, cy, gridSize * 0.2, Math.PI * 1.5, Math.PI * 0.5);
        }

        ctx.restore();
        ctx.closePath();
    }

    #drawEarCup(cx, cy, radius, startAngle, endAngle) {
        const { ctx } = this;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, startAngle, endAngle);
        ctx.closePath();
        ctx.fill();
    }

    #drawBody(part, prevPart, nextPart) {
        if (!prevPart || !nextPart) return;

        const { ctx, gridSize } = this;
        const dirPrev = SnakeRenderer.partDirection(prevPart, part);
        const dirNext = SnakeRenderer.partDirection(part, nextPart);
        const closedSides = SnakeRenderer.closedSides(dirPrev, dirNext);

        ctx.beginPath();
        ctx.rect(part.x, part.y, gridSize, gridSize);
        ctx.fillStyle = '#f9c95bff';
        ctx.fill();

        ctx.beginPath();
        ctx.strokeStyle = 'black';
        ctx.lineWidth = 2;

        if (closedSides.has('left')) {
            ctx.moveTo(part.x, part.y);
            ctx.lineTo(part.x, part.y + gridSize);
        }
        if (closedSides.has('right')) {
            ctx.moveTo(part.x + gridSize, part.y);
            ctx.lineTo(part.x + gridSize, part.y + gridSize);
        }
        if (closedSides.has('top')) {
            ctx.moveTo(part.x, part.y);
            ctx.lineTo(part.x + gridSize, part.y);
        }
        if (closedSides.has('bottom')) {
            ctx.moveTo(part.x, part.y + gridSize);
            ctx.lineTo(part.x + gridSize, part.y + gridSize);
        }
        ctx.fill();
        ctx.stroke();
    }

    #drawTail(part, prevPart) {
        const { ctx, gridSize } = this;
        const dir = SnakeRenderer.partDirection(prevPart, part);

        ctx.beginPath();
        switch (dir) {
            case 'left':
                ctx.moveTo(part.x, part.y);
                ctx.lineTo(part.x + gridSize, part.y);
                ctx.lineTo(part.x + gridSize, part.y + gridSize);
                ctx.lineTo(part.x, part.y + gridSize);
                break;
            case 'right':
                ctx.moveTo(part.x + gridSize, part.y);
                ctx.lineTo(part.x, part.y);
                ctx.lineTo(part.x, part.y + gridSize);
                ctx.lineTo(part.x + gridSize, part.y + gridSize);
                break;
            case 'up':
                ctx.moveTo(part.x, part.y);
                ctx.lineTo(part.x, part.y + gridSize);
                ctx.lineTo(part.x + gridSize, part.y + gridSize);
                ctx.lineTo(part.x + gridSize, part.y);
                break;
            case 'down':
                ctx.moveTo(part.x, part.y + gridSize);
                ctx.lineTo(part.x, part.y);
                ctx.lineTo(part.x + gridSize, part.y);
                ctx.lineTo(part.x + gridSize, part.y + gridSize);
                break;
            default:
                ctx.rect(part.x, part.y, gridSize, gridSize);
                break;
        }
        ctx.stroke();
        ctx.fill();
    }
}
